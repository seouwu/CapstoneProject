var date=new Date();
var today=document.getElementById("writeDate");
today.innerHTML=date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate();
